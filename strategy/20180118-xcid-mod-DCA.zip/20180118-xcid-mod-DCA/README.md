# Profit Trailer Settings - Binance

Start Balance on BTC was = 0.4
Returns are 300 - 600 USD

This trading is using BNB coin to reduce trading fees. 
Therefore buy some BNB on biance. 0.02 is fine.

There are notes in the pairs about this strat. 

BB - Bollinger Bands are volatility bands, placed above and below the moving average. The bands widen when volatility increases, and tighten when volatility decreases. LowBB is the BB setting used for buying. It lets you shrink the distance between the lower band and SMA (Simple Moving Average), so the bot buys your desired coin earlier than the lower band is reached. HighBB works same as LowBB, except it is for selling and works with the upper band. The BB strategy works well in almost any market conditions, with any coin.

You can find us on telegram
@XcidTrader & @wyukig

IF YOU WOULD LIKE TO TIP ME TO SAY THANKS FOR SHARING OR SIGN UP FOR BINANCE USING MY REF:

BINANCE REF: https://www.binance.com/?ef=12705936

BTC WALLET:1ApP5FgjSwCT4QVHRwCrvr7dCCvUErcL7z
