$('.dca-input').on('input', function () {
  var totalCap = parseFloat($('#dca-capital').val());
  var pairs = parseFloat($('#dca-pairs').val());
  var dcaLevels = parseFloat($('#dca-levels').val());
  var maxCost = parseFloat($('#dca-max-cost').val());
  var maxCostType = $('#dca-max-cost-type').val();
  if (maxCostType == 2) {
    maxCost = totalCap * maxCost / 100;
  }

  var costPerPair = Math.round10(maxCost * Math.pow(2, dcaLevels), -8);
  var totalCost = getDCACost(maxCost, pairs, dcaLevels, '')
  var result = Math.round10(totalCap - totalCost, -8);
  var resultPercent = Math.round10(result / totalCap * 100, -2);

  if (totalCap > 0 && isFloat(result)) {
    $('#dca-cost-pair').html(costPerPair);
    $('#dca-capital-needed').html(totalCost);
    $('#dca-result').html(result);
    $('#dca-result-percent').html(resultPercent + '%');

    $('#dca-result,#dca-result-percent').removeClass('text-success');
    $('#dca-result,#dca-result-percent').removeClass('text-danger');
    if (result > 0) {
      $('#dca-result,#dca-result-percent').addClass('text-success');
    } else {
      $('#dca-result,#dca-result-percent').addClass('text-danger');
    }

    $('#dca-noresult').css('display', 'none');
    $('#dca-result-table').css('display', 'table');
  }

  for (var c = 1; c <= 12; c++) {
    for (var r = 0; r <= 12; r++) {
      getDCACost(maxCost, c, r, '#dca-' + r + '-' + c);
    }
  }
});

function getDCACost(maxCost, pairs, dcaLevels, container) {
  var costPerPair = Math.round10(maxCost * Math.pow(2, dcaLevels), -8);
  var result = Math.round10(costPerPair * pairs, -8);
  var totalCap = parseFloat($('#dca-capital').val());

  if (isFloat(result)) {
    if (container != '') {
      $(container).html(result);

      $(container).removeClass('text-success');
      $(container).removeClass('text-danger');
      if (result < totalCap) {
        $(container).addClass('text-success');
      } else {
        $(container).addClass('text-danger');
      }
    }
  }

  return result;
}